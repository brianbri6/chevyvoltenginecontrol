due_can
=======

Object oriented canbus library for Arduino Due compatible boards

Download the archived 1.0 release if you are compiling against existing
code bases such as the EVTV GEVCU project. New projects will probably
find that the current "master" branch version of the project is easier
to use.
